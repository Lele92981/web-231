
const service1Name = "Basic";
const service2Name = "Express";
const service3Name = "Extreme";
const service4Name = "Ultimate";
const service1Speed = "50 Mbsp";
const service2Speed = "100 Mbsp";
const service3Speed = "500 Mbsp";
const service4Speed = "1 Gig";



document.getElementById("service2").innerHTML = "Express";


// document.getElementById("service3").innerHTML = "Extreme";

// document.getElementById("service4").innerHTML = "Ultimate";

// document.getElementById("service1Speed").innerHTML = "0 Mbps";

// document.getElementById("service2Speed").innerHTML = "100 Mbps";

// document.getElementById("service3Speed").innerHTML = "500 Mbps";

// document.getElementById("service4Speed").innerHTML = "1 Gig";
